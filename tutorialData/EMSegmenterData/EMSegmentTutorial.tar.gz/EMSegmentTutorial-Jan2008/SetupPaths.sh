
# you must change this to match your EMSegment tutorial directory
EMSEG_TUTORIAL_DIR=/playpen/davisb/EMSegmentTutorial-2.0

# you must change this to match your Slicer3 executable directory
SLICER_BIN_DIR=/usr/local/dev/build/Slicer3-GetBuildTest-Release/Slicer3-build/bin